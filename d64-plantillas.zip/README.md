# Plantillas D64 Carrillo

Generador web de plantillas operativas (decomiso de droga y motocicleta, aprehensión, violencia doméstica, persona fallecida, ZIP, control vehicular y novedad general). Se llena el formulario y se copia, se envía por WhatsApp o se descarga como .txt.

- Funciona sin servidor: todo ocurre en el navegador.
- Lo que se escribe se guarda solo en el dispositivo (localStorage); no se envía a ningún sitio.
- Tema claro, oscuro o automático. Se puede instalar como app (PWA) y funciona sin conexión.

## Publicar con GitHub Pages
1. Crea un repositorio y sube todos los archivos de esta carpeta a la raíz.
2. Ve a **Settings → Pages**.
3. En **Source** elige **Deploy from a branch**, rama **main** y carpeta **/ (root)**, y guarda.
4. En uno o dos minutos la página queda en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Aviso
La página es pública. No subas al repositorio datos reales de personas (nombres, cédulas, casos): usa la página solo para escribir y copiar, sin guardar nada en el repo.
